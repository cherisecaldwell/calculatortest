import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Operation } from '../interfaces/operation';
import { retry, catchError } from 'rxjs/operators';
import { CalculationRequest } from '../interfaces/calculation-request';

@Injectable({
  providedIn: 'root',
})
export class CalculatorService {
  private apiBaseUrl = environment.API_BASE_URL;
  private operationsEndPoint = environment.OPERATIONS_ENDPOINT;
  private calculateEndPoint = environment.CALCULATE_ENDPOINT;
  constructor(private readonly http: HttpClient) {}

  getOperations(): Observable<Operation[]> {
    return this.http
      .get<Operation[]>(this.apiBaseUrl + this.operationsEndPoint)
      .pipe(
        retry(1),
        catchError((error) => {
          let errorMsg: string;
          if (error.error instanceof ErrorEvent) {
            errorMsg = `Error: ${error.error.message}`;
          } else {
            errorMsg = this.getServerErrorMessage(error);
          }

          return throwError(errorMsg);
        })
      );
  }

  calculate(request: CalculationRequest): Observable<number> {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    return this.http
      .post<number>(this.apiBaseUrl + this.calculateEndPoint, request)
      .pipe(
        retry(1),
        catchError((error) => {
          let errorMsg: string;
          if (error.error instanceof ErrorEvent) {
            errorMsg = `Error: ${error.error.message}`;
          } else {
            errorMsg = this.getServerErrorMessage(error);
          }

          return throwError(errorMsg);
        })
      );
  }

  private getServerErrorMessage(error: HttpErrorResponse): string {
    switch (error.status) {
      case 404: {
        return `Not Found: ${error.message}`;
      }
      case 403: {
        return `Access Denied: ${error.message}`;
      }
      case 500: {
        return `Internal Server Error: ${error.message}`;
      }
      default: {
        return `Unknown Server Error: ${error.message}`;
      }
    }
  }
}
