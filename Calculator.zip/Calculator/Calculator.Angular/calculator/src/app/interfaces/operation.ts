export interface Operation {
    operationName:string;
}