export interface CalculationRequest{
      operationName:string;
      firstNumber:number;
      secondNumber:number;
}