import { Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormControl,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { CalculationRequest } from './interfaces/calculation-request';
import { Operation } from './interfaces/operation';
import { CalculatorService } from './services/calculator.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'Calculator';
  operations: Operation[];
  form: FormGroup;
  result?: number;

  constructor(
    private readonly calculatorService: CalculatorService,
    private readonly fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.calculatorService.getOperations().subscribe((operations) => {
      this.operations = operations;
    });
    this.buildForm();
  }

  buildForm() {
    this.form = this.fb.group({
      operationName: new FormControl(null, [Validators.required]),
      firstNumber: new FormControl(null, [Validators.required]),
      secondNumber: new FormControl(null, [Validators.required]),
    });
  }

  calculate() {
    this.result = undefined;
    if (this.form.invalid) return;
    const input = this.form.value as CalculationRequest;
    if (input.secondNumber === 0 && input.operationName === 'Division') {
      alert('Cannot divide by zero');
      return;
    }
    this.calculatorService.calculate(input).subscribe((result) => {
      this.result = result;
    });
  }

  reset() {
    this.result = undefined;
    this.form.reset();
  }
}
