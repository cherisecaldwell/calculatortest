export const environment = {
  production: true,
  API_BASE_URL:"http://localhost:5268/api/calculator/",
  OPERATIONS_ENDPOINT:"get-operations",
  CALCULATE_ENDPOINT:"",
};
