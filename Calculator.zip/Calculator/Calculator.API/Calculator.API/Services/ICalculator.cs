﻿using CalculatorAPI.Models;

namespace CalculatorAPI.Services
{
    public interface ICalculator
    {
        List<OperationsOutput> GetOperations();
        decimal Calculate(CalculationInput input);
    }
}
