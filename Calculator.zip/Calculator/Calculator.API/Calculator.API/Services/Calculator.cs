﻿using CalculatorAPI.Constants;
using CalculatorAPI.Models;

namespace CalculatorAPI.Services
{
    public class Calculator : ICalculator
    {
        public List<OperationsOutput> GetOperations()
        {
            return new List<OperationsOutput>
            {
                new OperationsOutput { OperationName=OperationType.Addition},
                new OperationsOutput { OperationName= OperationType.Division}
            };
        }

        public decimal Calculate(CalculationInput input)
        {
            return input.OperationName switch
            {
                OperationType.Addition => input.FirstNumber + input.SecondNumber,
                OperationType.Division => Math.Round(input.FirstNumber / input.SecondNumber,2),
                _ => 0
            };
        }
    }
}
