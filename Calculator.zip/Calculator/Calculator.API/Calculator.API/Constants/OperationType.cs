﻿namespace CalculatorAPI.Constants
{
    public static class OperationType
    {
        public const string Addition = "Addition";
        public const string Division = "Division";
    }
}
