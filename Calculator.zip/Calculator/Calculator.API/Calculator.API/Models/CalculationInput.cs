﻿using System.ComponentModel.DataAnnotations;

namespace CalculatorAPI.Models
{
    public class CalculationInput
    {
        [Required]
        public string OperationName { get; set; }

        [Required]
        public decimal FirstNumber { get; set; }

        [Required]
        public decimal SecondNumber { get; set; }
    }
}
