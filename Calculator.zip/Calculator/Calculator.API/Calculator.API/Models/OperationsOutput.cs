﻿namespace CalculatorAPI.Models
{
    public class OperationsOutput
    {
        public string OperationName { get; set; } = string.Empty;
    }
}
