using CalculatorAPI.Constants;
using CalculatorAPI.Models;
using CalculatorAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace CalculatorAPI.Controllers
{
    [ApiController]
    [Route("api/calculator")]
    public class CalculatorController : ControllerBase
    {
        private readonly ICalculator calculator;
        
        public CalculatorController(ICalculator calculator)
        {
            this.calculator = calculator;
        }

        [HttpGet("get-operations")]
        public IActionResult GetOperations()
        {
            return Ok(calculator.GetOperations());
        }

        [HttpPost("calculate")]
        public IActionResult Calculate([FromBody]CalculationInput input)
        {
            if (input.OperationName == OperationType.Division && input.SecondNumber == 0)
                return BadRequest("Cannot divide by zero");
            if (input.OperationName != OperationType.Division && input.OperationName != OperationType.Addition)
                return BadRequest("Invalid operation");
            return Ok(calculator.Calculate(input));
        }
    }
}