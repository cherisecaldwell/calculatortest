using CalculatorAPI.Controllers;
using CalculatorAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Xunit;

namespace CalculatorTest
{
    public class CalculatorUnitTest
    {
        private readonly ICalculator calculator;
        private readonly CalculatorController controller;
        public CalculatorUnitTest()
        {
            calculator = new Calculator();
            controller = new CalculatorController(calculator);

        }

        [Fact]
        public void Controller_Returns_Bad_Request_On_Invalid_Operation_In_Input()
        {
            var input = new CalculatorAPI.Models.CalculationInput
            {
                FirstNumber = 4,
                SecondNumber = 5,
                OperationName = "Invalid Operation"
            };
            var badResponse = controller.Calculate(input);
            Assert.IsType<BadRequestObjectResult>(badResponse);
        }

        [Fact]
        public void Controller_Returns_Bad_Request_On_Zero_As_SecondNumber_In_Input_With_Division()
        {
            var input = new CalculatorAPI.Models.CalculationInput
            {
                FirstNumber = 4,
                SecondNumber = 0,
                OperationName = "Division"
            };
            var badResponse = controller.Calculate(input);
            Assert.IsType<BadRequestObjectResult>(badResponse);
        }

        [Fact]
        public void Calculates_Correct_Addition()
        {
            var reuslt = calculator.Calculate(new CalculatorAPI.Models.CalculationInput
            {
                FirstNumber = 10,
                SecondNumber = 10,
                OperationName = "Addition"
            });

            Assert.Equal(20, reuslt);
        }

        [Fact]
        public void Calculates_Correct_Division()
        {
            var reuslt = calculator.Calculate(new CalculatorAPI.Models.CalculationInput
            {
                FirstNumber = 100,
                SecondNumber = 10,
                OperationName = "Division"
            });

            Assert.Equal(10, reuslt);
        }

        [Fact]
        public void Throws_Divide_By_Zero_Exception()
        {

            Assert.Throws<System.DivideByZeroException>(() => calculator.Calculate(new CalculatorAPI.Models.CalculationInput
            {
                FirstNumber = 10,
                SecondNumber = 0,
                OperationName = "Division"
            }));
        }
    }
}